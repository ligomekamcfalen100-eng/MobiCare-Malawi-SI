const express = require("express");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: "10kb" }));
app.use(express.static(path.join(__dirname, "public")));

const answers = {
  fever: {
    en: "A fever can have many causes, including infections. If possible, check the temperature, drink safe fluids, and rest. In Malawi, fever can be a sign of malaria or another illness, so contact a qualified health worker promptly and ask whether testing is needed. Symptoms alone cannot confirm the cause.",
    ny: "Malungo angayambitsidwe ndi matenda osiyanasiyana. Ngati n’kotheka, yezani kutentha kwa thupi, imwani madzi otetezeka ndipo mupumule. Ku Malawi, malungo angakhale chizindikiro cha malaria kapena matenda ena, choncho funsani ogwira ntchito zaumoyo mwamsanga kuti akulangizeni ngati mukufunika kuyezetsa. Zizindikiro zokha sizingatsimikizire chifukwa chake."
  },
  malaria: {
    en: "To reduce malaria risk, sleep under an insecticide-treated mosquito net and follow local public-health advice. Fever may be malaria or another illness; seek assessment and testing promptly from a qualified health worker. This tool cannot diagnose malaria.",
    ny: "Kuti muchepetse chiopsezo cha malaria, muzigona mu neti yothiridwa mankhwala ophera udzudzu ndipo muzitsatira malangizo a zaumoyo a m’dera lanu. Malungo angakhale malaria kapena matenda ena; pitani kwa ogwira ntchito zaumoyo kuti akuyeseni mwamsanga. Chida ichi sichingazindikire malaria."
  },
  water: {
    en: "Use water from a safe source when possible. If you are unsure whether water is safe, follow current local public-health guidance for treating drinking water. Store it in a clean, covered container and wash hands with soap at important times.",
    ny: "Ngati n’kotheka, gwiritsani ntchito madzi ochokera ku gwero lotetezeka. Ngati simukudziwa ngati madzi ndi otetezeka, tsatirani malangizo a zaumoyo a m’dera lanu powakonza kuti akhale oyenera kumwa. Sungani madzi m’chidebe choyera komanso chotsekedwa ndipo muzisamba m’manja ndi sopo nthawi zofunika."
  },
  clinic: {
    en: "Seek professional care when symptoms are worrying, persistent, worsening, or you are unsure what to do. Babies, pregnant people, older adults, and people with existing health conditions may need prompt advice. For severe or rapidly worsening symptoms, seek urgent medical care rather than waiting for an online answer.",
    ny: "Pitani kwa ogwira ntchito zaumoyo ngati zizindikiro zikukudetsani nkhawa, zikupitirirabe, zikukulirakulira, kapena simukudziwa chochita. Ana aang’ono, amayi apakati, okalamba, komanso anthu omwe ali ndi matenda ena angafunike thandizo mwamsanga. Ngati munthu akudwala kwambiri, funani chithandizo cha mwadzidzidzi m'malo modikira yankho la pa intaneti."
  }
};

const urgentTerms = [
  "can't breathe", "cannot breathe", "difficulty breathing", "seizure",
  "unconscious", "not waking", "severe bleeding", "chest pain",
  "sangathe kupuma", "kuvutika kupuma", "akukomoka", "sakuuka"
];

function classifyQuestion(question) {
  const q = question.toLowerCase();
  if (/(fever|temperature|malungo)/i.test(q)) return "fever";
  if (/(malaria|mosquito|udzudzu)/i.test(q)) return "malaria";
  if (/(water|madzi|drink|drinking)/i.test(q)) return "water";
  if (/(clinic|hospital|doctor|health worker|chipatala|thandizo)/i.test(q)) return "clinic";
  return "unknown";
}

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, app: "MobiCare Malawi", version: "0.2.0" });
});

app.post("/api/chat", (req, res) => {
  const question = typeof req.body.question === "string" ? req.body.question.trim() : "";
  const language = req.body.language === "ny" ? "ny" : "en";

  if (!question) {
    return res.status(400).json({ error: "Please enter a question." });
  }
  if (question.length > 1000) {
    return res.status(400).json({ error: "Please keep your question under 1,000 characters." });
  }

  const urgent = urgentTerms.some(term => question.toLowerCase().includes(term));
  const topic = classifyQuestion(question);
  let answer;

  if (urgent) {
    answer = language === "ny"
      ? "Zizindikirozi zingafune thandizo lachangu. Chonde funani chithandizo cha kuchipatala cha mwadzidzidzi nthawi yomweyo. Musadikire yankho la pa intaneti."
      : "These words may describe an emergency. Please seek urgent medical care now or contact local emergency services. Do not wait for an online answer.";
  } else if (topic === "unknown") {
    answer = language === "ny"
      ? "Prototype iyi ilibe yankho lotsimikizika la funsoli. Funsani ogwira ntchito zaumoyo kapena gwero lodalirika. Ngati zizindikiro ndi zazikulu kapena zikukulirakulira, funani chithandizo mwamsanga."
      : "This prototype does not yet have a verified answer for that question. Please consult a qualified health worker or trusted health source. If symptoms are severe or worsening, seek care promptly.";
  } else {
    answer = answers[topic][language];
  }

  res.json({
    answer,
    topic: topic === "unknown" ? "general" : topic,
    urgent,
    mode: "curated-demo",
    disclaimer: language === "ny"
      ? "Izi ndi maphunziro a zaumoyo basi, osati kupeza matenda kapena m'malo mwa dokotala."
      : "This is general health education, not a diagnosis or a substitute for a qualified health professional."
  });
});

app.use((err, _req, res, _next) => {
  console.error("Request error:", err.message);
  res.status(500).json({ error: "Something went wrong. Please try again." });
});

app.listen(PORT, () => {
  console.log(`MobiCare Malawi running on port ${PORT}`);
});
