# MobiCare Malawi v0.2

A beginner-friendly full-stack starter project for a bilingual health-information demo.

## What works
- `public/index.html`: frontend UI
- `server.js`: Node.js + Express backend
- `GET /api/health`: backend health check
- `POST /api/chat`: receives a question and language, returns a curated sample response
- Basic urgent-keyword warning and input validation
- No API key and no payment required for this demo

## Important limitation
This version is **not connected to an AI model**. The backend returns curated demo responses based on simple keyword matching. Do not describe it as a live AI chatbot. It is a first full-stack step before adding a secure model API and verified health-source retrieval.

It is not for diagnosis or treatment. Have health content and Chichewa translations reviewed by qualified local health professionals before public use. Do not collect personal medical information.

## Run locally or in a browser IDE
Requirements: Node.js 18+.

1. Open a terminal in the project folder.
2. Run `npm install`.
3. Run `npm start`.
4. Open the forwarded/preview port 3000.
5. Test `GET /api/health` and submit sample questions in the interface.

## Suggested beginner tests
- "How can I prevent malaria?"
- "What should I know about fever?"
- "How can I make drinking water safer?"
- "I have a question about a topic not listed."
- Test the urgent-warning behavior with a phrase such as "difficulty breathing" (this is only a basic demo check, not reliable emergency detection).

## Next steps
1. Upload this project to a GitHub repository.
2. Run it in GitHub Codespaces.
3. Test frontend-to-backend communication.
4. Add a secure server-side AI integration only after checking provider access, costs, age requirements, and privacy terms.
5. Add retrieval from trusted health sources, citations, safety evaluation, and professional review.
6. Deploy to a free test service only after the demo works locally. Free hosts can sleep or have other limits.
